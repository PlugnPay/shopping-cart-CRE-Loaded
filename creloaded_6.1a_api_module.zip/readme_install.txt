=================================================
Plug 'n Pay - API Method
Payment Module for CRE Loaded 6.1a
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will 
be given to help diagnose/address problems with this module.  The amount of support 
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the CRE Loaded community at 
'www.creloaded.com', and if you are still unable to resolve the issue, contact us 
via PlugnPay's Online Helpdesk.

This module is intended to use your own server's SSL abilities and will ask the 
customer for all of their credit card info directly in the CRE Loaded interface.  
The authorization will be done via PlugnPay's API Payment Method.  It is intended to 
itemize the order in the PlugnPay system using available information from the cart.

If you want to change the behavior of this module, please feel free to make changes 
to the files yourself.  However, customized CRE Loaded modules will not be provided 
support assistance.

In addition, you MUST have the cURL installed for CRE Loaded shopping cart to 
properly use this module.  This will also require you to have an SSL security 
certificate installed on your web server.  If you don't have this, then consider 
downloading/using a different version of this module instead; such as the Smart 
Screens or Direct Method versions.
***************************

Requirements:

This contribution at the time of this writing seems to work without incident with 
all versions of CRE Loaded v6.1 to date.

  You need to:
    * Be running some version of CRE Loaded v6.1.
    * Have access to cURL, either compiled into your flavor of PHP, or as a binary 
    (/usr/bin/curl or curl.exe), which you can point this contribution to.
    * Be running SSL with the latest certificates.


Usage Notes:

    * Failed orders are still assigned an order number - In order to be able to send 
    an order number to PlugnPay without having to rewrite a substantial portion of 
    CRE Loaded, the order is assigned an ID before it is approved by PlugnPay. These 
    orders are then deleted if the processing fails with PlugnPay, however it was 
    already assigned a number, so your order numbers will "skip" over that number.  
    There is no currently foreseeable way around this.


Installation:

   1.  Overwrites the previous files (there are a lot of changes in most of the 
   files, so it may be best if you have other contributions this overwrites to 
   take note of their changes, install these files, and then edit them).  You may 
   also want to remove these deprecated files if you used a previous version of 
   this contribution:

        * /loaded61a/images/cv_amex_card.gif
        * /loaded61a/images/cv_card.gif 

   2.  Make sure to uninstall and reinstall the contribution in the admin panel if 
   you were running a previous version, and fill in the blanks with your information.

   3.  Curl Setup:

        * If you do not have cURL compiled, select Not Compiled and input your cURL
        path. If you are on a Linux/Unix machine it will look something like 
        /usr/bin/curl/curl, and for Windows it will look like c:/curl/curl. Two 
        important things to note here, first is that you must include the last 
        "curl" in that path, i.e. the curl binary. Second, for Windows, you must 
        use the '/' slashes, as the '\' slashes are used for escape characters in PHP.

        * If you do have cURL compiled, select Compiled.


Explanation of Options:

    *Upon installing this contribution via the Admin panel, select "edit" to input 
    your information. You will be presented with many options you need to fill in 
    for this contribution to function properly:

	* Enable PlugnPay Module - Whether to use PlugnPay API to accept credit 
	  card payments.   
          (true if installed)

        * Login Username - Your alphanumeric login username given to you by 	    
          PlugnPay.
          (The same used to login to their website.)

        * Publisher Email - Enter an email address where you will receive your 
          merchant order confirmation emails sent by PlugnPay.

        * cURL Setup - Whether you are running cURL compiled into PHP or as a 
          standalone binary.
          (Windows users are standalone binaries, Linux/Unix can be either, ask your 
          host)

        * cURL Path - The full path to your curl binary (ex: curl.exe). This is 
          necessary only if you are running cURL as Not Compiled, and must include 
          the curl file as part of the path (i.e. c:/curl/curl).
          (Windows users: you must use the '/' as your directory separator, as �\'s 
          are used as escape characters in PHP)

        * Transaction Mode - The mode you wish to run your shopping cart in.   
          (Test, Test And Debug, Production).
            --> Test mode will only accept test credit card #s as given by PlugnPay
                & will not process real credit card #s.
            --> Test And Debug mode will do the same as test mode, but will also dump
                the output being sent to PlugnPay into the file "plugnpay_debug.txt" in 
                your /loaded61a/ directory.
            --> Production will run real credit card transactions

Use the following to run credit card tests through the PlugnPay payment gateway:

                Name On Card:  'cardtest' or 'card test'
                Card Type:     'Visa'
                Credit Card #: '4111111111111111'
                Exp Date:      Any expiration date after the current date
                CVV #:         '123'

                REMEMBER TO ACTIVATE THE "TESTING MODE" IN YOUR PLUGNPAY ADMINISTRATION
                AREA BEFOR RUNNING A TEST TRANSACTION

        * Require CVV - Have CRE Loaded shopping cart require CVV info for credit card
           purchases or not.

        * Send 2-Letter State - Have CRE Loaded send PlugnPay 2-letter state where possible
            --> 'yes' sends 2-letter state where possible & defaults to what
                 was typed in when no match is found
            --> 'no' sends what was typed into the address only (no conversion to 2 letter format) 

        * Transaction Method - The transaction method you are using to process orders.
            --> 'credit' will only offer credit card payment options
            --> 'onlinecheck' will offer credit card & electronic check payment options
                  (Only enable 'onlinecheck' if you have setup an electronic checking 
                  account with PlugnPay first.)

        * Authorization Type - The mode used to process credit cards settlements.
            --> 'authpostauth' means you want to authorize and capture the credit card 
                information.
                  (charge the cards & auto-settle those approved transactions)
            --> 'authonly' means you want to authorize only.
                  (charge the cards & later settle mark then for settlement via PlugnPay's
                  payment gateway.)

* Sort Order Of Display - The order in which this payment method is displayed with respect
  to other payment methods on the checkout_payment.php page. Lower numbers are displayed 
  above higher ones.

        * Customer Notifications - Controls whether email receipts should be sent directly
          from PlugnPay to the customer.
            --> 'yes' will prevent PlugnPay from sending an email conformation to the customer
            --> 'no' will allow PlugnPay to send an email conformation to the customer 

        * Accepted Credit Cards - Which cards the gateway is currently set up to accept.
            (Currently only American Express, Discover, MasterCard, and Visa are supported.)


Included Files:

    (* Note - these files will overwrite the current files if you copy over the directory
    structure)

    readme_install.txt
    /loaded61a/checkout_payment.php
    /loaded61a/checkout_process.php
    /loaded61a/cvv.html
    /loaded61a/admin/modules.php
    /loaded61a/images/cvv.jpg
    /loaded61a/images/icons/Amex.gif
    /loaded61a/images/icons/Discover.gif
    /loaded61a/images/icons/Mastercard.gif
    /loaded61a/images/icons/Visa.gif
    /loaded61a/includes/classes/cc_validation.php
    /loaded61a/includes/languages/english/modules/payment/plugnpay.php
    /loaded61a/includes/modules/plugnpay_api.php
    /loaded61a/includes/modules/payment/plugnpay.php


Troubleshooting:

Check to be sure you actually uploaded the files in the correct folders.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)
-- .gif files should be chmod 644
   (read/write by owner, read only by all others)
-- .txt files should be chmod 666
   (read/write by all [owner, group & nobody user])

When processing a transaction and it fails, there should be a PnP generated error 
message after the '--' in the response in your shopping cart.  This would tell the 
customer why PnP could not process the order.  If this is blank, then you should check
your cURL connection. 

There are 2 ways to check the cURL connection:

1 - Turn on the Test & Debug option, run a transaction and then look at the 
    'plugnpay_debug.txt' file in your loaded61a folder.
    -- The PREAUTH line is the string that was sent to PnP's servers via the cURL 
       connection.
    -- The POSTAUTH line is the string that was received by your cURL connection from
       PnP server.
    -- When the POSTAUTH line is blank, this means cURL did not make a connection to 
       PnP servers & is best to manually test cURL with the 2nd way below. 

2 - You can check this out by accessing the server via a shell account (SSH/Telnet) & 
    manually running a cURL connection.
    Run the following command from the command line of the server's shell and see if you 
    get a response string.

   /usr/bin/curl -d "publisher-name=pnpdemo&publisher-email=trash%40plugnpay.com&mode=auth&card-name=cardtest&card-number=4111111111111111&card-exp=0105&card-cvv=123&card-amount=1.23" https://pay1.plugnpay.com/payment/pnpremote.cgi
 

 *NOTES:
 -- THE ABOVE COMMAND SHOULD ALL BE ON ONE LINE
 -- You should adjust the path to curl (/usr/bin/curl) to whatever your server uses.
 -- You should get a response string similar to the one below.
 
 You should get a response string should look something like this, if it was successful.


   FinalStatus=success&IPaddress=209%2e51%2e163%2e251&MStatus=success&User%2dAgent=url%2f7%2e11%2e1%20%28i386%2dredhat%2dlinux%2dgnu%29%20libcurl%2f7%2e11%2e1%20OpenSSL%2f0%2e9%2e7a%20ipv6%20zlib%2f1%2e2%2e1%2e1&auth%2dcode=TSTAUT&auth%2dmsg=%2000%3a&auth_date=20040922&avs%2dcode=U&card%2damount=1%2e23&card%2dname=cardtest&currency=usd&cvvresp=M&easycart=0&merchant=pnpdemo&mode=auth&orderID=2004092215542323043&publisher%2demail=trash%40plugnpay%2ecom&publisher%2dname=pnpdemo&resp%2dcode=00&shipinfo=0&sresp=A&success=yes&transflags=retail&MErrMsg=00%3a&a=b

 *NOTE:
 -- THE ABOVE SHOULD ALL BE ON ONE LINE

If you get a certificate validation error, you can enter '-k' attribute between the path 
to curl & the '-d' parameter.  The '-k' parameter will turn off the SSL certificate 
validation.
 
If you get back a blank response there is most likely a firewall which is internal to 
your server/network which is preventing cURL from contacting our servers.
 
If cURL complied into your PHP is not working, but the command line cURL connection 
worked, use Not Compiled option & that same path to curl you used in your command line.

If this hasn't still fixed the issue, here are a few other suggestions.  You may want
to check the following: 

  * Your path to cURL is correctly inputted, if in Not Compiled mode.

  * If in Compiled mode, check if cURL is in fact compiled and working.

  * Your SSL is working and updated with the latest certificates.

  * You have uninstalled and reinstalled PlugnPay API module via the Admin panel if you 
    ran a previous version.

  * Your PlugnPay account's username inputted correctly into the Login Username field.

  * Your PlugnPay account is actually 'Live' & CRE Loaded is set in Production status, 
    so you can process real credit card transactions.

  * You have properly set up your PlugnPay account via our website, including setting
    all your Fraud settings & make sure your account is 'Live'.

  * If trying to process electronic checks, make sure you have an electronic checking 
    account setup with PlugnPay before starting to ask for/accept electronic check  
    payments.

Also, realize that this code itself is not very complex, and practically every person 
that has contacted us about errors found that some other code not associated with this
contribution was responsible, or because their cURL implementation was not properly set 
up or working.  Do your own debugging before contacting anyone for assistance.


API Module History:

05/12/2005
- converted osCommerce v2.2 API module to be used with CRE Loaded v6.1a

05/24/2005
- fixed issue with 'Authorization Type', which prevented correct setting of
  this field when authorization is submitted.

05/26/2005
- updated 'checkout_process.php' to play nice with other 3rd party payment modules

06/02/2005
- updated 'checkout_process.php' to prevent CRE Loaded emails from showing the
  products purchased twice.

